from django.urls import path
from . import views


urlpatterns = [

    # http://localhost:8000/products/sales
    path("sales", views.sales, name="sales"),

    # http://localhost:8000/products
    path("", views.list, name="products"),
    
    # http://localhost:8000/products/details/2
    path("details/<int:id>", views.details, name="details"),

    # http://localhost:8000/products/categories
    path("categories", views.categories, name="categories"),

    # http://localhost:8000/products/new
    path("new", views.insert, name="insert")

]