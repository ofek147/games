from django.db.models import Model, CharField, DecimalField, IntegerField, ForeignKey, RESTRICT, DateField
from datetime import datetime
from django.forms import DateInput, ModelForm, NumberInput, Select, TextInput

# Category model:
class CategoryModel(Model):
    
    # First column - id - will be created automatically.

    # Second column:
    name = CharField(max_length = 50)

    # __str__ magic method:
    def __str__(self):
        return self.name

    # Metadata:
    class Meta:
        db_table = "categories"

# ----------------------------------------------------------------------

# Product model:
class ProductModel(Model):

    # First column - id - will be created automatically.

    # Second column:
    name = CharField(max_length = 50)

    # Third column:
    price = DecimalField(max_digits = 6, decimal_places = 2)

    # Fourth column:
    stock = IntegerField()

    # Fifth column (relation):
    category = ForeignKey(CategoryModel, on_delete = RESTRICT)

    # Sixth column:
    release_date = DateField(default = datetime.now)

    # Metadata:
    class Meta:
        db_table = "products"

# ----------------------------------------------------------------------

# Product form model - describing how to build a product form:
class ProductForm(ModelForm):

    class Meta:
        model = ProductModel
        # fields = ["name", "price", "stock", "category", "release_date"]
        exclude = ["id"]

        widgets = {
            "name": TextInput(attrs = { "class": "form-control", "minlength": 2, "maxlength": 100 }), # attrs = HTML Attributes
            "price": NumberInput(attrs = { "class": "form-control", "min": 0, "max": 1000 }),
            "stock": NumberInput(attrs = { "class": "form-control", "min": 0, "max": 1000 }), 
            "category": Select(attrs = { "class": "form-control" }), 
            "release_date": DateInput(attrs = { "class": "form-control", "type": "date" })
        }


