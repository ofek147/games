from django.shortcuts import redirect, render
from .models import ProductForm, ProductModel, CategoryModel

# Sales view:
def sales(request):
    context = {"active": "sales"}
    return render(request, "sales.html", context)

# Products view:
def list(request):
    products = ProductModel.objects.all()
    context = {"active": "products", "products": products}
    return render(request, "products.html", context)

# Single product details view:
def details(request, id):
    product = ProductModel.objects.get(pk = id) # PK = Primary Key
    context = {"product": product}
    return render(request, "details.html", context)

# Categories view:
def categories(request):
    categories = CategoryModel.objects.all()
    context = {"active": "categories", "categories": categories}
    return render(request, "categories.html", context)

# Insert view: 
def insert(request):
    if request.method == "GET":
        context = {"active": "insert", "form": ProductForm()}
        return render(request, "insert.html", context)
    
    form = ProductForm(request.POST)
    form.save() # Save in database
    return redirect("products")
