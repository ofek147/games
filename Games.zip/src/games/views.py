from django.shortcuts import render

# Home view:
def home(request): # View Function (request is an object containing request data.)
    context = {"active": "home"}
    return render(request, "home.html", context)

# About view:
def about(request):
    context = {"active": "about"}
    return render(request, "about.html", context)