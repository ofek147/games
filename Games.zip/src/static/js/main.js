
setInterval(() => {
    const aboutHeader = document.getElementById("aboutHeader")
    if(aboutHeader) {
        aboutHeader.style.color = '#' + Math.floor(Math.random()*16777215).toString(16)
    }
}, 3000)
